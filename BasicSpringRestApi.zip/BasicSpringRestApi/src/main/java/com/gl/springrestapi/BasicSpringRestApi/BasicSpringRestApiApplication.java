package com.gl.springrestapi.BasicSpringRestApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages={"com.gl.springrestapi.BasicSpringRestApi","com.gl.springrestapi.BasicSpringRestApi.controller","com.gl.springrestapi.BasicSpringRestApi.dao","com.gl.springrestapi.BasicSpringRestApi.service","com.gl.springrestapi.BasicSpringRestApi.entity"})
public class BasicSpringRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(BasicSpringRestApiApplication.class, args);
		System.out.println("Hello World");
	}

}
