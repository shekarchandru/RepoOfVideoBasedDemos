package com.gl.springrestapi.BasicSpringRestApi.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.gl.springrestapi.BasicSpringRestApi.entity.Employee;

@Repository
public class EmployeeDao {

	ArrayList <Employee> employees;
	
	public EmployeeDao()
	{
		employees = new ArrayList<Employee>();
		employees.add(new Employee("E001","Harsha","RTNagar"));
		employees.add(new Employee("E002","Suman","RJNagar"));
		employees.add(new Employee("E003","Kiran","JayaNagar"));
		employees.add(new Employee("E004","Rajesh","Malleswaram"));
	}
	
	public List getEmployees()
	{
		return employees;
	}
}
