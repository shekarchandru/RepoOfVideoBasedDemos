package com.gl.springrestapi.BasicSpringRestApi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.springrestapi.BasicSpringRestApi.service.EmployeeService;

@RestController
@RequestMapping("/hello")
public class HomeController {
	
	@Autowired
	EmployeeService empService;
	
	@RequestMapping("/greet")
	public String sayHello()
	{
		return "Welcome To SpringBOOT based RestAPI With Simulated Data";
	}
	
	@GetMapping("/employees")
	public List getEmployees()
	{
		return empService.getEmployeesSvc();
	}

}
